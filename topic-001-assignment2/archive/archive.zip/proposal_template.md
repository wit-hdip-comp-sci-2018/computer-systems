# Project Name
#### Student Name: *xxx*   Student ID: *xxx*

TODO: Write a short project description.

## Tools, Technologies and Equipment

TODO: Write a list of things you propose to use in your work. This can be hardware, programming languages etc.

## Project Repository
TODO: Create a repository for your project. You can add this proposal to it!


